from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

import os
import streamlit as st
from dotenv import load_dotenv

### define the api key

# Access the variables
openai_key = os.getenv("OPENAI_API_KEY")
langchain_key = os.getenv("LANGCHAIN_API_KEY")
project_name = os.getenv("LANGCHAIN_PROJECT")
### define prompt template

promt = ChatPromptTemplate.from_messages(
    [
        ("system", "You are a helpful assistant. Please response to the user queries"),
        ("user", "Question: {question}")
    ]
)


### define the streamlit framework

st.title("Basic chatbot using Langchain  and OpenAI")
input_text = st.text_input("Enter your question here")   ### then we define the input text


# ### define the model
llm=ChatOpenAI(model="gpt-3.5-turbo")
### define the output parser
output_parser= StrOutputParser()

### then combine all of this
chain= promt | llm | output_parser

if input_text:
    st.write(chain.invoke({"question": input_text})) ## take the input text and invoke the chain to get the response 
    



